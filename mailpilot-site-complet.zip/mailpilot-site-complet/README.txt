================================
MAILPILOT - PACKAGE COMPLET DU SITE
================================

Ce dossier contient ton site MailPilot tout-en-un.

----------------------------------------
NOUVEAUTE : SITE EN UN SEUL FICHIER
----------------------------------------

L'ancien systeme avait 2 pages (index.html + demo.html).
Maintenant tout est dans UN SEUL FICHIER : index.html.

La demo interactive est integree directement dans la page
d'accueil. Tous les boutons "Demander une demo" ont ete
remplaces par "Lancer la demo".

----------------------------------------
CONTENU DU DOSSIER
----------------------------------------

[A] Fichiers a UPLOADER sur GitHub :

    site-pour-github/
        index.html             (page d'accueil + demo integree)
        mentions-legales.html  (page legale obligatoire RGPD)

[B] Fichiers BONUS (a utiliser ailleurs, PAS sur GitHub) :

    logos/
        logo-mark.svg          (vectoriel haute qualite)
        logo-mark-1024.png     (avatar haute def Gmail/LinkedIn)
        logo-mark-512.png      (taille standard)

    video-demo/
        mailpilot-demo.gif     (GIF anime pour signature email/socials)

----------------------------------------
COMMENT METTRE LE SITE EN LIGNE
----------------------------------------

ETAPE 1 : Aller sur GitHub
    - Connecte-toi sur github.com
    - Ouvre ton repo "mailpilote"

ETAPE 2 : Supprimer l'ancien fichier demo.html (s'il existe)
    - Sur GitHub, clique sur demo.html dans la liste
    - Clique sur l'icone poubelle en haut a droite
    - Tout en bas, clique "Commit changes"

ETAPE 3 : Uploader les 2 nouveaux fichiers
    - Retourne a la racine du repo
    - Clique "Add file" puis "Upload files"
    - Glisse-depose les 2 fichiers du dossier "site-pour-github"
        index.html
        mentions-legales.html
    - Confirme le remplacement de index.html
    - Clique le bouton vert "Commit changes"

ETAPE 4 : Attendre 30 secondes
    - Vercel detecte le changement automatiquement
    - Va sur ton URL pour voir le resultat
    - Force le rafraichissement avec Cmd+Shift+R

----------------------------------------
URLS A PARTAGER
----------------------------------------

    Site principal      : mailpilote.vercel.app
    Mentions legales    : mailpilote.vercel.app/mentions-legales.html

(Plus besoin de partager /demo.html, la demo est sur la home)

----------------------------------------
INFOS DU SITE
----------------------------------------

    Email contact   : mailpilot.contact86@gmail.com
    Editeur         : Thomas RIBREAU
    Adresse         : 6 rue du Sanital, 86100 Chatellerault
    Telephone       : 06 59 51 27 12
    Logo            : Concept "IA Mail" (enveloppe + etincelle violette)
    Hebergeur       : Vercel Inc.

----------------------------------------
PROCHAINES ETAPES SUGGEREES
----------------------------------------

    1. Mettre logo-mark-1024.png en avatar Gmail et LinkedIn
    2. Preparer 3 templates de reponses Gmail
    3. Ouvrir un compte Calendly pour les RDV de demo
    4. Lancer la prospection LinkedIn avec mailpilot-demo.gif
